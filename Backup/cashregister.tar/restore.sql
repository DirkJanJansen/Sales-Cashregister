--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.1
-- Dumped by pg_dump version 12.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE cashregister;
--
-- Name: cashregister; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE cashregister WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'Dutch_Netherlands.1252' LC_CTYPE = 'Dutch_Netherlands.1252';


ALTER DATABASE cashregister OWNER TO postgres;

\connect cashregister

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accounts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.accounts (
    "barcodeID" character varying(8) NOT NULL,
    firstname character varying(20) DEFAULT ''::character varying,
    lastname character varying(30) DEFAULT ''::character varying,
    access integer DEFAULT 1,
    callname character varying(20) DEFAULT ''::character varying
);


ALTER TABLE public.accounts OWNER TO postgres;

--
-- Name: COLUMN accounts."barcodeID"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.accounts."barcodeID" IS 'EAN 8 for Identification staff members';


--
-- Name: COLUMN accounts.access; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.accounts.access IS '1. Employee          (sales)
2. Manager            (access return items)
3. Administrator   (program changes, imports, prices)';


--
-- Name: articles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.articles (
    barcode character varying(13) NOT NULL,
    description character varying(50) DEFAULT ''::character varying,
    item_price double precision DEFAULT 0,
    item_stock double precision DEFAULT 0,
    item_unit character varying(6) DEFAULT ''::character varying,
    minimum_stock double precision DEFAULT 0,
    order_size double precision DEFAULT 0,
    location_warehouse character varying(8) DEFAULT ''::character varying,
    article_group character varying(40) DEFAULT ''::character varying,
    thumbnail character varying(50) DEFAULT ''::character varying,
    photo character varying(50) DEFAULT ''::character varying,
    category integer DEFAULT 0,
    order_balance double precision DEFAULT 0,
    order_status boolean DEFAULT true,
    mutation_date character varying(10) DEFAULT ''::character varying,
    annual_consumption_1 double precision DEFAULT 0,
    annual_consumption_2 double precision DEFAULT 0,
    "BTW" character varying(4) DEFAULT 'hoog'::character varying
);


ALTER TABLE public.articles OWNER TO postgres;

--
-- Name: buttons; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.buttons (
    "buttonID" integer NOT NULL,
    buttontext character varying(20) DEFAULT ''::character varying,
    barcode character varying(13) DEFAULT ''::character varying NOT NULL
);


ALTER TABLE public.buttons OWNER TO postgres;

--
-- Name: params; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.params (
    "paramID" integer NOT NULL,
    item character varying(20) DEFAULT ''::character varying,
    value double precision DEFAULT 0
);


ALTER TABLE public.params OWNER TO postgres;

--
-- Name: payments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payments (
    "payID" integer NOT NULL,
    kind character varying(25) DEFAULT ''::character varying,
    amount double precision DEFAULT 0,
    bookdate character varying(10) DEFAULT ''::character varying,
    paydate character varying(10) DEFAULT ''::character varying,
    instance character varying(25) DEFAULT ''::character varying,
    accountnumber character varying(25) DEFAULT ''::character varying,
    "ovorderID" integer DEFAULT 0
);


ALTER TABLE public.payments OWNER TO postgres;

--
-- Name: purchases; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.purchases (
);


ALTER TABLE public.purchases OWNER TO postgres;

--
-- Name: sales; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sales (
    "ID" integer NOT NULL,
    receiptnumber integer DEFAULT 0,
    barcode character varying(13) DEFAULT ''::character varying,
    description character varying(40) DEFAULT ''::character varying,
    number double precision DEFAULT 0,
    item_price double precision DEFAULT 0,
    sub_total double precision DEFAULT 0,
    sub_vat double precision DEFAULT 0
);


ALTER TABLE public.sales OWNER TO postgres;

--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.accounts ("barcodeID", firstname, lastname, access, callname) FROM stdin;
\.
COPY public.accounts ("barcodeID", firstname, lastname, access, callname) FROM '$$PATH$$/2887.dat';

--
-- Data for Name: articles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.articles (barcode, description, item_price, item_stock, item_unit, minimum_stock, order_size, location_warehouse, article_group, thumbnail, photo, category, order_balance, order_status, mutation_date, annual_consumption_1, annual_consumption_2, "BTW") FROM stdin;
\.
COPY public.articles (barcode, description, item_price, item_stock, item_unit, minimum_stock, order_size, location_warehouse, article_group, thumbnail, photo, category, order_balance, order_status, mutation_date, annual_consumption_1, annual_consumption_2, "BTW") FROM '$$PATH$$/2888.dat';

--
-- Data for Name: buttons; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.buttons ("buttonID", buttontext, barcode) FROM stdin;
\.
COPY public.buttons ("buttonID", buttontext, barcode) FROM '$$PATH$$/2889.dat';

--
-- Data for Name: params; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.params ("paramID", item, value) FROM stdin;
\.
COPY public.params ("paramID", item, value) FROM '$$PATH$$/2890.dat';

--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payments ("payID", kind, amount, bookdate, paydate, instance, accountnumber, "ovorderID") FROM stdin;
\.
COPY public.payments ("payID", kind, amount, bookdate, paydate, instance, accountnumber, "ovorderID") FROM '$$PATH$$/2891.dat';

--
-- Data for Name: purchases; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.purchases  FROM stdin;
\.
COPY public.purchases  FROM '$$PATH$$/2892.dat';

--
-- Data for Name: sales; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sales ("ID", receiptnumber, barcode, description, number, item_price, sub_total, sub_vat) FROM stdin;
\.
COPY public.sales ("ID", receiptnumber, barcode, description, number, item_price, sub_total, sub_vat) FROM '$$PATH$$/2893.dat';

--
-- Name: sales ID_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT "ID_pkey" PRIMARY KEY ("ID");


--
-- Name: accounts barcodeID_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT "barcodeID_pkey" PRIMARY KEY ("barcodeID");


--
-- Name: CONSTRAINT "barcodeID_pkey" ON accounts; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT "barcodeID_pkey" ON public.accounts IS 'Primary Key';


--
-- Name: articles barcode_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.articles
    ADD CONSTRAINT barcode_pkey PRIMARY KEY (barcode);


--
-- Name: CONSTRAINT barcode_pkey ON articles; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT barcode_pkey ON public.articles IS 'Primary Key';


--
-- Name: buttons buttonID_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.buttons
    ADD CONSTRAINT "buttonID_pkey" PRIMARY KEY ("buttonID");


--
-- Name: params paramID_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.params
    ADD CONSTRAINT "paramID_pkey" PRIMARY KEY ("paramID");


--
-- Name: payments payID_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT "payID_pkey" PRIMARY KEY ("payID");


--
-- Name: barcode_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX barcode_idx ON public.articles USING btree (barcode);


--
-- PostgreSQL database dump complete
--

